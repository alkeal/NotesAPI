exports.handler = async (event, context) => {


    return 'Hej';
   
   
   
   }